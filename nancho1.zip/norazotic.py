import random

subject = ['makerel', 'wild horse', 'crab', 'shrimp', 'python', 'tuna', 'curry']
ransub = random.choice(subject)
verb = ['shower', 'eat', 'run', 'fall', 'do', 'fail', 'pass', 'walk']
ranverb = random.choice(verb)
norazotic = ['NaNaNaNaNaNaNaNaNaNa', "WhahoWhatwaowahoowahoowa", "Ssso Sssossosso Ssso so so so"]
rannor = random.choice(norazotic)
object = ['makerel', 'wild horse', 'crab', 'shrimp', 'python', 'tuna', 'curry']
ranobj = random.choice(object)

subto = ['makerel', 'wild horse', 'crab', 'shrimp', 'python', 'tuna', 'curry']
runsubto = random.choice(subto)
veb = ['shower', 'eat', 'run', 'fall', 'do', 'fail', 'pass', 'walk']
runveb = random.choice(veb)
norazotic = ['NaNaNaNaNaNaNaNaNaNa', "WhahoWhatwaowahoowahoowa", "Ssso Sssossosso Ssso so so so"]
runnor = random.choice(norazotic)
objectect = ['makerel', 'wild horse', 'crab', 'shrimp', 'python', 'tuna', 'curry']
runobject = random.choice(objectect)

print(runnor + ' ' +ransub + ' ' + ranverb + ' ' + runsubto+' ' + runveb +' '+ runnor + ' ' +runnor+ ' ' + ranobj +ranobj + ranobj + runnor)

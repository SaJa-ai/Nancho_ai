print("SaJaAi version 3 β")
print("login into SaJa Tools beta terminal")
username = input("Username >> ")
pwd = input("Password >> ")

user1 = "Jihwan"
user2 = "SaJaOfficial"
user3 = "Hacker"

pwd = "sajasince2017"

if pwd == "sajasince2017":
	if username == user1:
    		print("Welcome, father")
	elif username == user2:
    		print("Welcome, SaJa official member")
	elif username == user2:
                print("Welcome, Hacker, ready to hack the system?")
	exec(open("SaJaAi.py").read())
else:
    print("Access denied")

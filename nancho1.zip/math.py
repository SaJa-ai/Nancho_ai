jegop = """
*제곱근
1) a의 제곱근
	제곱하여 a가 되는수
	x^2 = a
	a>0: 2개
	a=0: 0(1개)
	a<0: 0개
"""
print(jegop)
print("only makerel by Norazo is avalable now.")
s = input("what song do you want to sing?")
makerel = "makerel"
a = """
This song is sung by Norazo.
chamchi? kkongchi? galchi? godeungeo!
wouwo wouwowowowo u!
wouwo wouwowowowo ha!
sso sso sso sso sso sso sso sso sola sola sola

assa assa assa a ssaneulhan balam
atteu atteu atteu a tteugeoun taeyang
geochin donghaebada dalligo dallinda neoege ganda

adeung adeung adeung a deungpuleun saengseon
attong attong attong a donggeulan nunal
geudaemaneul wihan D.H.A naneun godeungeoyeola

dallyeola eogiya diyeola lacha eogiya diyeola lacha
supyeongseon jeo kkeutkkaji

nopi naneun saecheoleom nalchicheoleom
taepyeongyangeul nubineun chamchicheoleom
puleun kkumgwa puleun deung,
puleun haneullo nopi nala olla olla
saeudeungeul teoteulin golaecheoleom
himilamyeon kingwangjjang mulgaecheoleom
gudeun simji gudeun kkang gudeun uijilo
geochin pado hechyeo hechyeo

wouwo wouwowowowo u!
wouwo wouwowowowo ha!
sso sso sso sso sso sso sso sso sola sola sola

aya aya aya a yamujin mommae
abiu abiu abiu a Beautiful saengseon
geudaemaneul wihan omega3 naneun godeungeoyeola

dallyeola eogiya diyeola lacha eogiya diyeola lacha
supyeongseon jeo kkeutkkaji

nopi naneun saecheoleom nalchicheoleom
taepyeongyangeul nubineun chamchicheoleom
puleun kkumgwa puleun deung,
puleun haneullo nopi nala olla olla
saeudeungeul teoteulin golaecheoleom
himilamyeon kingwangjjang mulgaecheoleom
gudeun simji gudeun kkang gudeun uijilo
geochin pado hechyeo hechyeo

wouwo wouwowowowo u!
wouwo wouwowowowo ha!
sso sso sso sso sso sso sso sso sola sola sola

godeungeo!
nopi naneun saecheoleom nalchicheoleom
taepyeongyangeul nubineun chamchicheoleom
puleun kkumgwa puleun deung,
puleun haneullo nopi nala olla olla
subaegnyeoneul gidalin jinjucheoleom
sumannyeoneul dallyeoon padocheoleom
chagawossdeon kkumdeuli ilueo jilgeolago
mideo mideo mideo
u! ha!
	"""

if s == makerel :
	print(a)
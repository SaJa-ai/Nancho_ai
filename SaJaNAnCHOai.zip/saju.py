opt = """
za = "1"
chuch = "2"
ien = "3"
myeou = "4"
jin = "5"
sa  = "6"
oeh = "7"
mee = "8"
sin ="9"
you = "10"
sool = "11"
hae = "12
"""


print(opt)
te = input("What is your te? ~# ")
x = input("your birth month ~# ")
y = input("your birthday ~# ")
z = input("Your birth time ~# ")



onetotwenty = float(te)
twentytoforty = float(te) + float(x)
fortytosixty = float(te) + float(y)
sixtytodeath  = float(te) + float(z)


print(onetotwenty)
print(twentytoforty)
print(fortytosixty)
print(sixtytodeath)
print("these are your numbers of sajasaju. input your numbers in the next question.")
ont = input("your first #")
ttf = input("your second #")
fts = input("your third")
std = input("your forth")

if ont == "1" :
	print("good")

if ont == "2" :
	print("bad")
	
if ont == "3" :
	print("good")

if ont == "4" :
	print("bad")
	
if ont == "5" :
	print("good")
	
if ont == "5" :
	print("good")
	
if ont == "6" :
	print("good")
	
if ont == "7" :
	print("bad")
	
if ont == "8" :
	print("bad")
	
if ont == "9" :
	print("bad")
	
if ont == "10" :
	print("good")
	
if ont == "11" :
	print("good")
	
if ont == "12" :
	print("good")
	
if ttf == "1" :
	print("good")

if ttf == "2" :
	print("bad")
	
if ttf == "3" :
	print("good")

if ttf == "4" :
	print("bad")
	
if ttf == "5" :
	print("good")
	
if ttf == "5" :
	print("good")
	
if ttf == "6" :
	print("good")
	
if ttf == "7" :
	print("bad")
	
if ttf == "8" :
	print("bad")
	
if ttf == "9" :
	print("bad")
	
if ttf == "10" :
	print("good")
	
if ttf == "11" :
	print("good")
	
if ttf == "12" :
	print("good")
	
if fts == "1" :
	print("good")

if fts == "2" :
	print("bad")
	
if fts == "3" :
	print("good")

if fts == "4" :
	print("bad")
	
if fts == "5" :
	print("good")
	
if fts == "5" :
	print("good")
	
if fts == "6" :
	print("good")
	
if fts == "7" :
	print("bad")
	
if fts == "8" :
	print("bad")
	
if fts == "9" :
	print("bad")
	
if fts == "10" :
	print("good")
	
if fts == "11" :
	print("good")
	
if fts == "12" :
	print("good")

